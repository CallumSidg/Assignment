package U4ProgrammingA2;

import java.util.Iterator;


public class Player implements Actions {//Players details

    protected String firstName;
    protected String lastName;
    protected String teamName;
    
    int count = 0;

    public void player(String firstName, String lastName) {//Puts all details of players together
        this.firstName = firstName;
        this.lastName = lastName;
        this.teamName = firstName + lastName;
    }

    public String getFirstName() {//Their name is now entered
        return firstName;
    }

    public String getLastName() {//Name is now entered
        return lastName;
    }

    public String getTeamName() {//Asks for their team name
        return teamName;
    }

    @Override
    public void setFirstName() {
        System.out.println("Enter first name");//Scans for their name
        this.firstName = InputFactory.SC.next();
    }

    @Override
    public void setLastName() {
        System.out.println("Enter last name");//Scans for their last name
        this.lastName = InputFactory.SC.next();
    }

    @Override
    public void setTeam() {
        this.teamName = firstName + lastName;//Puts their name with their team
    }
    
    @Override
    public void addToArrayList(){//Lists all players with their team
        String deats = (firstName + "\t" + lastName + "\t" + teamName);
        ShortStore.listPlayer.add(deats);
    }

    @Override
    public void add() {//Lists all players and teams with 20 charachter limit
        while(ShortStore.listPlayer.size() <= 20) {
            setFirstName();
            setLastName();
            setTeam();
            addToArrayList();
        }
        Menu menu = new Menu();
    }

    @Override
    public void view() {//Players get added first
        

        if (ShortStore.listPlayer.isEmpty()) {
            System.out.println("Add players first");
        }
        
        System.out.println("list" + ShortStore.listPlayer);
        
        
        Iterator itr = ShortStore.listPlayer.iterator();  
        while (itr.hasNext()) {  
            System.out.println(itr.next());  

        } 
    }

    @Override
    public void remove() {
        ShortStore.listPlayer.clear();//Clear or remove from list
    }
}