
package U4ProgrammingA2;


public interface Actions {//The options available when entering players and teams into the system
        public void add();
        public void view();
        public void remove();
        public void setFirstName();
        public void setLastName();
        public void setTeam();
        public void addToArrayList();

}
