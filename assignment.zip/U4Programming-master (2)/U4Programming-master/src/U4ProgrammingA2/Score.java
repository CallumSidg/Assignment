
package U4ProgrammingA2;


public class Score {//Scoring system

    public void scoringSystem() {

    }

}
