
package U4ProgrammingA2;


public class Tournament extends Event {
    
    public static void createTournament(){//The creation of the tournamnet 
        
    }
    
    public static void tournamentResults(){//The scores from that tournament
        
    }
    
}
