package U4ProgrammingA2;

import java.util.Iterator;


public class Team extends Player implements Actions {//Team limit extends
    Player player = new Player();

    public void teamPlayer(String firstName, String lastName, String teamName) {//Puts all names together
        this.firstName = firstName;
        this.lastName = lastName;
        this.teamName = teamName;
    }
    
    @Override
    public void setFirstName() {//Enter first name
        player.setFirstName();
    }

    @Override
    public void setLastName() {//Enter last name
        player.setLastName();
    }

    @Override
    public void setTeam() {//Enter team name
        System.out.println("Enter team name");
        this.teamName = InputFactory.SC.next();
    }

    @Override
    public void add() {//Adds all names to array
        while(ShortStore.listTeam.size() <= 20) {
            setFirstName();
            setLastName();
            setTeam();
            addToArrayList();
        }
        Menu menu = new Menu();
    }

    @Override
    public void addToArrayList(){//Stores all details on list
        String deats = (player.firstName + "\t" + player.lastName + "\t" + teamName);
        ShortStore.listPlayer.add(deats);
    }
    
    @Override
    public void view() {
        if (ShortStore.listTeam.isEmpty()) {
            System.out.println("You have no teams");//Says there are no teams if list empty
        }

        for (Iterator<String> iterator = ShortStore.listPlayer.iterator(); iterator.hasNext();) {
            String team = iterator.next();
            System.out.println(team);
        }
    }

    @Override
    public void remove() {
        ShortStore.listPlayer.clear();//Clear or remove from list
    }
}
