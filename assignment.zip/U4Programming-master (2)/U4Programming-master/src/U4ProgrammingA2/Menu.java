package U4ProgrammingA2;

import static U4ProgrammingA2.InputFactory.SC;


public class Menu {
    private String sInput;

    public Menu() {//The inputs for the players and teams
        int iInput;
        Player player = new Player();
        Team team = new Team();

        do {
            System.out.println("Select from the following:\n"//The options like adding players or deleting them
                    + "1. Add Player         \t4. Add Team\n"
                    + "2. View Player       \t5. View Team\n"
                    + "3. Delete Player    \t6. Delete Team\n"
                    + "7. Create Tournament"
                    + "0. Exit\n");

            
            while (!InputFactory.SC.hasNextInt()) {
                System.out.println("Whole numbers only");//Wraning to only eneter whole numbers
                InputFactory.SC.next();
            }

            iInput = InputFactory.SC.nextInt();

            if (iInput == 1) {//Options for adding players and teams
                player.add();
                break;
            } else if (iInput == 2) {
                player.view();
                break;
            } else if (iInput == 3) {
                player.remove();
                break;
            } else if (iInput == 4) {
                team.add();
                break;
            } else if (iInput == 5) {
                team.view();
                break;
            } else if (iInput == 6) {
                team.remove();
                break;
            }
        } while (iInput != 0);
    } 
    
    public static void eventType(){//The input for which event you are playing in     
        int iInput;
        
        do{
            System.out.println("One event or Five\n"//Choose between how many events you are playing 
                        + "1. One Event\n"
                        + "2. Five Events");
            iInput = SC.nextInt(); 

            while(!InputFactory.SC.hasNextInt()){
                System.out.println("Must be 1 or 2");//Warns that you only pick from them choices
                InputFactory.SC.next();
            }

        }while(iInput < 0 || iInput > 2);
        
        if(iInput != 1){
            Event.singleOrFiveEvents = 5;
        }

        individualOrTeam();
    }    
    
    public static void individualOrTeam(){//The options between being a team or individual
        int iInput;
        
        do{
            System.out.println("One event or Five\n"
                        + "1. individual\n"
                        + "2. team");
            iInput = SC.nextInt(); 

            while(!InputFactory.SC.hasNextInt()){
                System.out.println("Must be 1 or 2");
                InputFactory.SC.next();
            }

        }while(iInput < 0 || iInput > 2);
        
        if(iInput != 2){
            Event.singleOrFiveEvents = 2;
        }
        sportingOrAcademic();
    }
    
    public static void sportingOrAcademic(){//Which event you are playing in
        int iInput;
        
        do{
            System.out.println("One event or Five\n"
                        + "1. sporting\n"
                        + "2. academic");
            iInput = SC.nextInt(); 

            while(!InputFactory.SC.hasNextInt()){
                System.out.println("Must be 1 or 2");
                InputFactory.SC.next();
            }

        }while(iInput < 0 || iInput > 2);
        
        if(iInput != 2){
            Event.sportingOrAcademic = 2;
        }
    }
    
    public static String collate(){
        
        return "";
    }
    


}
