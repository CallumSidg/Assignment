package U4ProgrammingA2;


public class Main {//Main method
    private static int input;

    public static void main(String[] args) {

        Menu.eventType();
        

    }
}
