
package U4ProgrammingA2;

import java.util.Scanner;


public class InputFactory {
    protected static Scanner SC = new Scanner(System.in);

    public static int checkInput(int iInput){

        return iInput;
    }
}
