package U4ProgrammingA2;


public class Event {//How many events and which events
    protected static int singleOrFiveEvents = 1;
    protected static int individualOrTeam = 1; 
    protected static int sportingOrAcademic = 1; 
        
    public static void registerForEvent(){//The regiser method
        
    }
    
    public static int getEvents(){//The amounts of events you are playing
        return singleOrFiveEvents;
    }
    
    public static void individualOrTeam(){//Which team you are part of or if individual
        
    }
    
    public static void updateScore(){//Update scores after event
        
    }
}
